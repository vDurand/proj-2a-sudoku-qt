/**
 * @authors BASS Yannick & DURAND Valentin
 * ENSICAEN 2017
 */

#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    srand(time(NULL));

    QApplication a(argc, argv);

    MainWindow w;
    w.show();

    return a.exec();
}
